const taskListEl = document.getElementById('taskList');
const taskForm = document.getElementById('taskForm');

let tasks = [];

taskForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const title = document.getElementById('taskTitle').value.trim();
    const description = document.getElementById('taskDescription').value.trim();
    const time = document.getElementById('taskTime').value;
    const priority = document.getElementById('taskPriority').value;

    if (!title || !priority) {
        alert("Please enter task title and select priority.");
        return;
    }

    const task = { id: Date.now(), title, description, time, priority };
    tasks.push(task);

    taskForm.reset();
    renderTasks();
});

function renderTasks() {
    taskListEl.innerHTML = '';
    // Show newest task on top
    for (let i = tasks.length - 1; i >= 0; i--) {
        const task = tasks[i];
        const li = document.createElement('li');
        li.className = 'task-card';

        li.innerHTML = `
            <div class="task-title">${task.title}</div>
            <div class="task-description">${task.description || ''}</div>
            <div class="task-time">${task.time ? '⏰ ' + task.time : ''}</div>
            <span class="priority-tag priority-${task.priority}">${task.priority}</span>
            <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
        `;

        taskListEl.appendChild(li);
    }
}

function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    renderTasks();
}
