# mini_task_scheduler.py
from datetime import datetime

class TaskScheduler:
    def __init__(self):
        self.stack = []

    def add_task(self, title, description, time=None):
        if time is None:
            time = datetime.now().strftime("%Y-%m-%d %H:%M")
        task = {
            "title": title,
            "description": description,
            "time": time
        }
        self.stack.append(task)
        return f"Task '{title}' added."

    def remove_task(self):
        if self.stack:
            removed = self.stack.pop()
            return f"Task '{removed['title']}' removed."
        return "No tasks to remove."

    def remove_task_by_index(self, index):
        if 0 <= index < len(self.stack):
            removed = self.stack.pop(index)
            return f"Task '{removed['title']}' removed."
        return "Invalid task index."

    def view_tasks(self):
        return self.stack[::-1]

if __name__ == "__main__":
    scheduler = TaskScheduler()
    while True:
        print("\n1. Add Task\n2. Remove Last Task\n3. Remove Task by Index\n4. View Tasks\n5. Exit")
        choice = input("Enter choice: ")
        if choice == '1':
            title = input("Enter task title: ")
            desc = input("Enter task description: ")
            time = input("Enter task time (YYYY-MM-DD HH:MM) or leave blank for now: ")
            time = time if time.strip() else None
            print(scheduler.add_task(title, desc, time))
        elif choice == '2':
            print(scheduler.remove_task())
        elif choice == '3':
            idx = int(input("Enter index of task to remove (0 = oldest): "))
            print(scheduler.remove_task_by_index(idx))
        elif choice == '4':
            tasks = scheduler.view_tasks()
            if tasks:
                print("Current Tasks (Top to Bottom):")
                for i, t in enumerate(tasks):
                    print(f"{i}. {t['title']} (at {t['time']})")
                    print(f"   Description: {t['description']}")
            else:
                print("No tasks.")
        elif choice == '5':
            break
        else:
            print("Invalid choice.")
